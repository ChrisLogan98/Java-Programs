//Chris Logan
//CSC 161
//2/6/18
//Sorting names
package lab6;

import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author cjlogan
 */
public class Lab6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException{
        
        Scanner myScanner = new Scanner(System.in);
        String resp;
        PopularNames popularnames = new PopularNames("names.txt"); //creates popularnames object
        String[] names = popularnames.quickSort(popularnames.nameArray); //puts nameArray into a String[]
        for(int i = 0; i < names.length - 1; i++){
            System.out.println(names[i]); //prints out the entire name array sorted alphabetically
        }
        System.out.println("PROGRAM STATUS: ONLINE");
        System.out.println("Welcome to the 1990s Popular name sorter!");
        System.out.println("If looking for popular names from the 90s is your thing than you've found the right program!");
        System.out.println("Type YES to continue!"); //snarky statement asks if you want to use the program. 
        resp = myScanner.nextLine();
        while(resp != "done"){ //breaks program if the user types done in
           System.out.println("Type in a name");
           resp = myScanner.nextLine(); //this will loop until user types in done
           if(resp.equals("done")){
               System.out.println("Program status: TERMINATED");
               System.exit(0); //breaks loop and ends program}
           }
           else{
               resp = resp.replaceAll("[^a-zA-Z]", "");
               resp = resp.toUpperCase(); //removes all characters and puts all letters to lower case
               int found = popularnames.binarySearch(names, resp); //used binary search to find the name and compare it to the resp
               
               if(found == -1){
                   System.out.println("That name was not found in this list"); //if found = -1, it prints this out
               }
               else{
                    System.out.println("That name was found in this list"); //if it returns anything else, it prints this out
               }
           
           }
            
         
           
          
           
           
        }
        
         //PopularNames popularnames = new PopularNames("names.txt");
            //System.out.println(popularnames.nameArray);
        
    }
}
