//Chris Logan
//CSC 161
//2/6/18
//Class for sorting names
package lab6;

import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;


public class PopularNames {
    String names;
    String[] nameArray;
    public PopularNames(String fileName) throws FileNotFoundException{
        File filed = new File("names.txt"); //reads in txt file
        Scanner file = new Scanner(filed);
        while (file.hasNextLine()){ 
            //puts the whole line in a String
            names = names + " " + file.nextLine();  //breaks names up and reads the next line in the file
        }
        nameArray = names.split(" "); //splits names up and places it into the array
        file.close(); //closes file
    }
    
    public String[] quickSort(String[] name){
        doQuicksort(name, 0, name.length - 1); //puts the quicksort method into this method
        return name; //returns name for the array
    }
    
    public void doQuicksort(String[] name, int start, int end){
        if(start < end){
            //get pivot point
            int pivotPoint = partition(name, start, end);
            //sort the first list
            doQuicksort(name, start, pivotPoint - 1);
            //sorts the second list
            doQuicksort(name, pivotPoint + 1, end);
            
        } 
    }
    
    public int partition(String[]name, int start, int end){
       String pivotValue; //holds pivot value
       int endOfLeftList; //last thing in the list
       int middle; //middle
       
       //This will be the pivot value
       middle = (start + end) / 2;
       //Moves pivot value to the start of the list
       swap(name, start, middle);
       
       //save pivot value for comparison
       pivotValue = name[start];
       //end of the sublist is saved here
       endOfLeftList = start;
       //Scans list and moves any values that are less than the pivot value on the left list
       for(int s = start + 1; s <= end; s++){
           if(name[s].compareTo(pivotValue) < 0){
               endOfLeftList++;
               swap(name, endOfLeftList, s);
           }
       }
       //move pivot value to the end
       swap(name, start, endOfLeftList);
       //return pivot value
       return endOfLeftList;    
    }
    
    public void swap(String[] name, int a, int b){
        String temp;
        //swaps things from a to b
        temp = name[a];
        name[a] = name[b];
        name[b] = temp;
    }
    
    public int binarySearch(String[] name, String value){
        int first;
        int last; //values and assorted fun stuff
        int middle;
        int position;
        boolean found; 
        
        //sets up values
        first = 0;
        last = name.length - 1;
        position = -1;
        found = false;
        //searchs for a value
        while(!found && first <= last){
            middle = (first + last) / 2; //finds midpoint
            
            if(name[middle].compareTo(value) == 0){
                found = true; //if the value is found at the midpoint
                position = middle;
            }
            else if(name[middle].compareTo(value) > 0){ //this happens when the value is in the lower half
                last = middle - 1;
            }
            else{ //or if its in the upper half
                first = middle + 1;
            }
        }
        //returns position 
        return position;
    }
    
}
