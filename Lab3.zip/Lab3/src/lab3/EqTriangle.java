//Chris Logan
//CSC 161
//1/16/18
//Holds eq-triangle stuff
package lab3;

/**
 *
 * @author cjlogan
 */
public class EqTriangle extends RegularPolygon{
    
    public EqTriangle (double side){
        super(side);
        
    }
    public double getArea(){ //returns area
        double a, t, e; 
        a = Math.pow(side,2);
        t = Math.sqrt(3);
        area = ((t / 4) * a); //why must Java make these formulas so difficult to type in?
        return area;
    }
}
