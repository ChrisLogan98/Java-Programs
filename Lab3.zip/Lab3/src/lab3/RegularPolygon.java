//Chris Logan
//CSC 161
//1/16/18
//Holds shape related classes and stuff
package lab3;

/**
 *
 * @author cjlogan
 */
public abstract class RegularPolygon {
    protected double side; //side
    protected double area; //area
    
    //constructor 
    public RegularPolygon(double givenSide){
        side = 4; //sets side to 4
        side = givenSide;
        
    }

    //Gets area
    public double getArea()
    { 
         return this.area; //returns area
    } 
    
    
}
