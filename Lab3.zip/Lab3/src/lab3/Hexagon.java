//Chris Logan
//CSC 161
//1/16/18
//Holds hexagon related things
package lab3;


public class Hexagon extends RegularPolygon{
    
    public Hexagon(double side){
        super(side);
    }
    public double getArea(){ //returns area
        double a, w, q, t, y;
        a = Math.pow(side, 2);
        w = 3 * Math.sqrt(3);
        q = ((w / 2) * a);
        area = q; // Again, things could be alot easier but no, I have to break everything up
        return area;
    }
}
