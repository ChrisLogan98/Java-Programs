//Chris Logan
//CSC 161
//1/16/18
//Shape side creator
package lab3;

/**
 *
 * @author cjlogan
 */
public class Lab3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("This program literally prints out areas of shapes. Enjoy"); //sarcastically reminds user that no input is required
        System.out.println("No user input required. Just click run and watch the area print out");
        
        Square square = new Square(4); //square side length is 4
        EqTriangle triangle = new EqTriangle(4); //triangle side length is 4
        Pentagon pentagon = new Pentagon(4); //pentagon side length is 4
        Hexagon hexagon = new Hexagon(4); // hexagon side length is 4
        
        System.out.println(); //prints out the area for all the shapes
        System.out.println("The area of the Square is " + square.getArea() + " ft ");
        System.out.println("The area of the Eqilateral Triangle is " + triangle.getArea()+ " ft ");
        System.out.println("The area of the Pentagon is " + pentagon.getArea() + " ft ");
        System.out.println("The area of the Hexagon is " + hexagon.getArea() + " ft ");
    }
    
}
