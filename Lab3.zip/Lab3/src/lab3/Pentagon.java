//Chris Logan
//CSC 161
//1/16/18
//Holds pentagon related things
package lab3;


public class Pentagon extends RegularPolygon{

    public Pentagon(double side){
        super(side);
    }
    
    public double getArea(){ //returns area
        double e, r, t;
        double w = 0.25;
        e = Math.pow(side, 2);
        r = 5 * (5 + 2 * Math.sqrt(5));
        t = Math.sqrt(r);
        area = w * t * e; //don't even get me started on how much anger this formula caused me. 
        return area;
    }
    
}
