//Chris Logan
//CSC 161
//1/16/18
//Holds square related stuff
package lab3;


public class Square extends RegularPolygon{
   
     public Square (double side){
        super(side);
    }
    
    public double getArea(){ //returns area
        area = Math.pow(side, 2);
        return area; //this was the only easy one out of the bunch
    }
    
    
}
