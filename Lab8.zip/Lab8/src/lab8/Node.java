/* Jennifer Dust 
 * Modified by Chris Logan
 * 2/11/18
 * This is is the structure for creating nodes which are utilized by linked lists
 * This class controls the nodes
 */
package lab8;

public class Node 
{
   private String data;
   Node next;
	
   public Node(String i, Node n)
   {
      data = i;
      next = n;
   }
	
   public Node(String i)
   {
      data = i;
      next = null;
   }
	
   public void setNext(Node n)
   {
      next = n;
   }
	
   public String getData()
   {
      return data;
   	
   }
	
   public void setData(String d)
   {
      data = d;
   }
	
   public Node getNext()
   {
      return next;
   }
}  // end class Node
