/* Jennifer Dust 
 * Modified by Chris Logan
 * 2/11/18
 * This is is the structure for creating singly-linked lists
 * This is the list class. Controls the entire list and other assorted fun things
 */
package lab8;

public class LinkedList  
{

    /**
     *
     */
    public Node head;

    // constructor
    public LinkedList()
    {
       head = null;
    }

    public LinkedList(Node n)
    {
       head = n;
    }

    public boolean isEmpty()
    {
       return (head == null);
    }

    // add a new data member to a linked list
    public void add(String e)
    {
       Node n = new Node(e);
       add(n);
    }

    public void add(int location, String e)
    {
        // create a new node first
       Node n = new Node(e);
        // call the 'regular' add method
       add(location, n);

    }
    
    // put a new node at the end of the linked list
    public void add(Node n)
    {
       if (head == null)  // the list is empty
          head = n;
       else
       {
          Node p = head;
         // use node pointer p to
         // 'walk down' the list until
         // it gets to the node whose
         // next field is null
          while(p.getNext() != null)
             p = p.getNext();

         // set the next field to be the
         // node that was passed in

          p.setNext(n);

       }  // end else clause
    }  // end method add

    // add a node at a designated location in a linked list
    public void add(int location, Node n)
    {
       if (location == 0)
       // add at beginning of list
       {
          n.setNext(head);
          head = n;
       }
       else
       {
          Node p = head;
          Node q = null;

          try {

             int count = 0;
            // walk down the list
             while (count < location)
             {
                q = p;
                p = p.getNext();
                count++;
             }
            // put the new node in the
            // list after p
             q.setNext(n);
             n.setNext(p);


          }  // end try
          catch (NullPointerException e)
          {
             add(n);
             System.out.println("Oops - " + e.getMessage());
          }  // end catch
       }  // end else


    }  // end method to add at a location


    // remove a node that contains a given value
    public boolean remove(String i)
    {
       boolean retVal = false;
       if (head.getData() == i)
       {
          head = head.getNext();
          retVal = true;
       }
       else
       {
          Node p = head;
          Node q = null;
          while((p.getData() != i) && (p.getNext() != null))
          {
             q = p;
             p = p.getNext();
          }
          if (p.getData() == i)
          {
             q.setNext(p.getNext());
             retVal = true;
          }

       }

       return retVal;
    } // end method remove


    // method to display the contents of 
    // a linked list
    public void display()
    {
       System.out.print("The list contains: ");
       Node p = head;
       while (p != null)
       {
          System.out.print(p.getData() + " ");
          p = p.getNext();
       }
       System.out.println();
    }
    
    public boolean update(String h, String g){
       boolean succ = false;
       Node n = head; //sets n to beginning
       Node j = null; //sets j to end
       
       while(!n.getData().equals(h) && n.getNext() != null){
           j = n; //sets j equal to n
           n = n.getNext();
       }
       
       if(n.getData().equals(h)){ //if the data in n equals the data in h
           n.setData(g);          //it will update g and return true
           succ = true;
       }
       
        return succ;
    }
    
    public boolean exists(String e){
        boolean found = false;
        
        Node r = head; //beginning
        Node g = null; //end
        
        while((!r.getData().equals(e)) && (r.getNext() != null)){
            g = r; //sets g equals to r
            r = r.getNext();
        }
        
        if(r.getData().equals(e)){ //when r equals e, its found
            System.out.println(e + " is in the list");
            found = true;
        }
        else{
            System.out.println(e + " is not in the list");
            //since e isn't in the list, returns false
        }
        
        return found;
    }
    
    public int size(){
        Node w = head;
        Node q = null;
        
        int c = 0; //keeps count
        if(w == null){ //if the list is empty
            return 0;
        }
        
        while(w.getNext() != null){
            w = w.getNext();
            c++; //if the list isn't empty, mark it up by 1
        }
        return c;
    }
}  // end class LinkedList
