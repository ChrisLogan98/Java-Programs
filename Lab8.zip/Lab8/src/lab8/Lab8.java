/* Jennifer Dust 
 * Modified by Chris Logan
 * 2/11/28
 * Lab 8 - Testing Linked Lists and how they work. 
 * Prints out everything and makes my life easier
 */
package lab8;

public class Lab8 {
    

    public static void main(String[] args) 
    {
        //Create our list
        LinkedList llist = new LinkedList();
        LinkedList llist2 = new LinkedList();
        LinkedList llist3 = new LinkedList();
        
        //add values to the list
        llist.add("Hello");
        llist.add("from");
        llist.add("far");
        llist.add("far");
        llist.add("away");
        
        //display the list and adds very to the list
        llist.add(2,"very");
        llist.display();
        
        llist2.add("Ice");
        llist2.add("Cream");
        llist2.add("is");
        llist2.add("very");
        llist2.add("cold!");
        llist2.display();
        //changes very to super
        boolean ex = llist2.update("very","super");
        if(ex == true){
            System.out.println("TRUE"); //returns true if the words are true
        }
        else{
            System.out.println("FALSE"); //returns false
        }
        llist2.display();
        //updates every to always
        boolean exl = llist2.update("every", "always");
        if(exl == true){
            System.out.println("TRUE"); //returns true if the words are true and updates accordingly
        }
        else{
            System.out.println("FALSE"); //returns false
        }
        llist2.display();
        
        llist2.exists("Ice"); //checks is ice, cream and farts are in the list
        llist2.exists("Cream");
        llist2.exists("Farts");
        
        //prints out all the lists sizes
        System.out.println("The first list is " + llist.size() + " big");
        System.out.println("The second list is " + llist2.size() + " big");
        System.out.println("The third list is " + llist3.size() + " big");
        
        
        
    }
}