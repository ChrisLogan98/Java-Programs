
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Miles Shamo, Chris Logan
 * CSC 161
 * 1/11/18
 * Programming Assignemnt 1
 * Project1.java - The Main method responsible for user input/output
 */
public class Project1 {

    public static void main(String[] args) throws FileNotFoundException {
        //Create a dictionary
        Dictionary text = new Dictionary("src\\words.txt"); //location of txt file. Change filepath if need be
        //create a keyboard
        Keyboard board = new Keyboard(); // creates a keyboard to store the key and nearby keys
        //main loop
        Scanner myScanner = new Scanner(System.in);
        String resp;
        int i;
        resp = " ";
        while (resp != "done") { //start of while loop. User can type "done" and the program will terminate
            System.out.println("Enter a text message. Type 'done' to exit");
            resp = myScanner.nextLine(); //takes user response
            
            if (resp.equals("done")) { 
                System.out.println("Program status: TERMINATED");
                System.exit(0); //breaks loop and ends program}
            }
            String[] words = resp.split(" "); //creates string of words for easy usage

            for (String word : words) { //enhanced for loop loops through each word in the array
                word = word.replaceAll("[^a-zA-Z]", ""); //removes special characters and upper case letters
                if (!word.equals("")) { 
                    ArrayList hits = new ArrayList(); //hits keeps tabs on words that are already printed
                    System.out.print(word + ":\t");
                    word = word.toLowerCase(); // puts all words to lower case.
                    for (i = 0; i < word.length(); i++) { // another for loop loops through the length of the word

                        String keys = board.getKeys(Character.toString(word.charAt(i))); 
                        if (keys != null) {
                            for (int j = 0; j < keys.length(); j++) { //this for loop goes through each letter and compares it to printed words
                                String temp = word; 
                                temp = temp.substring(0, i) + keys.charAt(j) + temp.substring(i + 1); // swaps out the correct character with a letter from keys
                                if (text.checkForWord(temp)) { 
                                    boolean isPresent = false; //makes sure the same word isn't repeated twice
                                    for (int k = 0; k < hits.size(); k++) {
                                        if (hits.get(k).equals(temp)) { //check to see if word is already present
                                            isPresent = true;
                                        }
                                    }

                                    if (!isPresent) { //if word isn't present, add to list
                                        hits.add(temp);
                                    }
                                }
                            }
                        }
                    }

                    if (hits.isEmpty()) { //if the word isn't found, this startment will print out.
                        System.out.print("Word Not Found");
                    } else {
                        for (i = 0; i < hits.size(); i++) { //prints out all found words
                            System.out.print(hits.get(i) + " "); 

                        }
                    }

                    System.out.println(); //left for spacing/neatness. 
                    System.out.println(); //left for spacing/neatness
                }

            }
        }
    }

}
