/*
 * Miles Shamo, Chris Logan
 * CSC 161
 * 1/11/18
 * Programming Assignemnt 1
 * Dictionary.java - A dictionary class which loads in words from a text file
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;

public class Dictionary 
{
    //An arraylist of dictionary words
    private ArrayList words = new ArrayList();
    
    
    /*************************************************
     * Constructor - reads in and creates a file a arrayList containing all dictionary words
     * @param fileName - the file to be read in
     */
    Dictionary(String fileName) throws FileNotFoundException
    {

        //creates a file
        File file = new File(fileName);
        
        //creates a scanner to read the file
        Scanner getWord = new Scanner(file);
        
        //adds all words in file to the dictionary
        while (getWord.hasNextLine())
        {
            //all words are on their own line
            String temp = getWord.nextLine();
            
            //adds each word
            words.add(temp);
        }
    }
    
    /*************************************************
     * checkForWord loops through the dictionary and sees if the word is present
     * @param word - the word to check
     * @return - a boolean signifying whether the word is in the dictionary
     */
    public boolean checkForWord(String word)
    {
        //loops through every item in the dictionary
        for(int i = 0; i < words.size(); i++)
        {
            //if the word is found
            if(word.equals(words.get(i)))
            {
                //return true
                return true;
            }
        }
        
        return false;
    }
    
    /********************************************************
     * addWord - adds a word to the dictionary if it is not already present
     * @param word - the word to add
     */
    public void addWord(String word)
    {
        boolean isDuplicate = false;
        
        //loops through every item in the dictionary
        for(int i = 0; i < words.size(); i++)
        {
            //if the word is found
            if(word.equals(words.get(i)))
            {
                //return true
                isDuplicate = true;
            }
        }
        
        //adds the word if it isn't already present
        if(!isDuplicate)
        {
            words.add(word);
        }
    }
}
