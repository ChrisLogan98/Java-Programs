/*
 * Miles Shamo, Chris Logan
 * CSC 161
 * 1/11/18
 * Programming Assignemnt 1
 * Keyboard.java - a keyboard class which models the relationships between keys on the keyboard in a hashmap
 */

import java.util.HashMap;

public class Keyboard 
{
    //------------------------------------------------------Data Members
    private HashMap<String, String> keys;

    
    /**********************************************************
     * Constructor - creates a hashMap and adds all the necessary key-value pairs to model a keyboard's near keys
     * 
     */
    public Keyboard() {
        //initializes the hashmap
        this.keys = new HashMap();
        
        //adds all the key-value pairs to model a keyboard
        
        //row 1
        keys.put("q", "qasw");
        keys.put("w", "wqasde");
        keys.put("e", "ewsdfr");
        keys.put("r", "redfgt");
        keys.put("t", "trfghy");
        keys.put("y", "ytghju");
        keys.put("u", "uyhjki");
        keys.put("i", "iujklo");
        keys.put("o", "oiklp");
        
        //row 2
        keys.put("a", "azxswq");
        keys.put("s", "sazxcdewq");
        keys.put("d", "dsxcvfrew");
        keys.put("f", "fdcvbgtre");
        keys.put("g", "gfvbnhytr");
        keys.put("h", "hgbnmjuyt");
        keys.put("j", "jhnm,kiuy");
        keys.put("k", "kjmloiu");
        keys.put("l", "lkpoi");
        
        //row 3
        keys.put("z", "zxsa");
        keys.put("x", "xzcdsa");
        keys.put("c", "cxvfds");
        keys.put("v", "vcbgfd");
        keys.put("b", "bvnhgf");
        keys.put("n", "nbmjhg");
        keys.put("m", "mnlkj");
                
    }
    
    /*********************************************************
     * getKeys - returns a key's associated nearby keys
     * @param key - the key to be fetched from
     * @return - a string of all keys nearby it
     */
    public String getKeys(String key)
    {
        //gets the keys
        String nearKeys = keys.get(key);
        
        return nearKeys;
    }
}
