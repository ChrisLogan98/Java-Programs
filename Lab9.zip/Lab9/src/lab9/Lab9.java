//Chris Logan
//CSC 161
//2/28/18
//Checking for palindromes using stacks and lists
package lab9;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author cjlogan
 */
public class Lab9 {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException{
      String palindrome = " ";
      String fisLine;
      File file = new File("palindromes.txt"); //reads in the file
      Scanner in = new Scanner(file);
      while(in.hasNextLine()){ //if there is a line
          fisLine = in.nextLine(); //fisLine = that next line
          palindrome = fisLine; //sets palindrome equal to fisLine
          boolean isAPalindrome = checkPalindrome.palCheck(palindrome);
          if(isAPalindrome == true){ 
              System.out.println(fisLine + " is a palindrome"); //returns true if palindrome
          }
          else{
              System.out.println(fisLine + " is not a palindrome"); //returns false if not palindrome
          }
      }
    in.close(); //closes file
        
    }
 }
