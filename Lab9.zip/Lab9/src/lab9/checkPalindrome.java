//Chris Logan
//CSC 161
//2/27/18
//This class checks the palindrome status and returns it
package lab9;

import java.util.Stack;

/**
 *
 * @author cjlogan
 */
public class checkPalindrome {
    
    public static boolean palCheck(String toCheck){
        boolean isAPal = true;
        Stack<Character> string = new Stack<>(); //creates stack of characters
        
       for(int x = 0; x < toCheck.length(); x++){
           string.add(toCheck.charAt(x)); //adds everything in toCheck to stack
       }
       char[] letters = new char[toCheck.length()]; //creates character array
       for(int h = 0; h < letters.length; h++){
           string.push(letters[h]); //splits everything up by character
       }
       
       for(int x = 0; x < letters.length; x++){
           if(string.pop() != letters[x]){ //checks each character
               isAPal = false; //returns false if character is different
           }
       }
      
        return isAPal; //returns boolean value
    }
}
