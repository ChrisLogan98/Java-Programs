//Chris Logan
//CSC 161
//1/23/18
//Practice with interfaces
package lab4part1;
import java.util.Scanner;
/**
 *
 * @author cjlogan
 */
public class Lab4Part1{

    
    public static void main(String[] args) {
        Scanner myScanner = new Scanner(System.in);
        int a, b;
        System.out.println("Enter 2 numbers, then press <SPACE>");
        a = myScanner.nextInt();
        b = myScanner.nextInt();
        
        try{
            Combiner combinedValues = (a1, b1) -> (a1 / b1);
            System.out.println("The divided value of " + a + " by " + b + " is "+ combinedValues.combine(a, b));
        }
        catch(ArithmeticException e){
            System.out.println("Well..............");
            System.out.println("I mean, it could be worse");
            System.out.println("You could explode into a ball of flame or get teleported to Saturn");
            System.out.println("But this is fine too, I guess");
        }
    }
    
   
    
}
