//Chris Logan
//CSC 161
//1/23/18
//Interface for Lab 4
package lab4part1;

/**
 *
 * @author cjlogan
 */
public interface Combiner {
    //Abstract method because it is an interface
    public int combine (int num1, int num2);
    
}
