//Chris Logan
//CSC 161
//1/9/18
//Class that checks palindrome
package lab2;


public class Palindrome {
    public static boolean palCheck(String resp, int a, int stringLength){
        if(resp.charAt(a) != resp.charAt(stringLength)){ //checks the word the user types in from front to back
            return false; //if any letter is not the same, returns false
        }
        else if(stringLength == 1){
            return true; //returns true
        }
        else{ //returns true
            a++; //goes up the string length
            stringLength--; //goes down the string length
            return palCheck(resp, a, stringLength); //returns everything
        }
      
    }
    
}
