//Chris Logan
//CSC 161
//1/9/18
//Palindrome checker
package lab2;
import java.util.Scanner;

public class Lab2 {

   
    public static void main(String[] args) {
       Scanner myScanner = new Scanner(System.in);
       String resp;
       
       System.out.println("Program status: ONLINE");
       System.out.println("This program will determine if the word you enter is a palindrome");
       System.out.println("Type 'Yes' to continue");
       System.out.println("You can also type 'done' to quit");
       resp = myScanner.nextLine();//gets information from the user
       while(resp != "done"){ //breaks program if the user types done in
           System.out.println("Enter another word");
           resp = myScanner.nextLine(); //this will loop until user types in done
           if(resp.equals("done")){
               System.out.println("Program status: TERMINATED");
               System.exit(0); //breaks loop and ends program}
           }
           
           resp = resp.replaceAll("[^a-zA-Z]", "");
               resp = resp.toLowerCase(); //removes all characters and puts all letters to lower case
               
               boolean isAPalindrome = Palindrome.palCheck(resp,0,resp.length()-1);
               if(isAPalindrome == true){
                   System.out.println("This word is a palindrome");
               } //prints out true if the word is a palindrome
               else{
                   System.out.println("This word is not a palindrome");
               }//prints out false if word is not a palindrome
         }
      
           
       
       
    }
    
}
