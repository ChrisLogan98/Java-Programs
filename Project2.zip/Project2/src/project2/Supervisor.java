//Chris Logan, Sam Perez
//CSC 161
//1/25/18
//Program 2
package project2;

//Supervisor is a subclass to employee
public class Supervisor extends Employee {
    
        // variable unquie to supervisors
        double bonus;
        double annualSalary;
        
    //Constructor that reads in a String Array
    public Supervisor(String[] dataArray2){
        //passing in the super variables
        super(dataArray2);
        //making these numbers doubles so we can calculate the gross weekly pay
        annualSalary = Double.parseDouble(dataArray2[5]);
        bonus = Double.parseDouble(dataArray2[6]);
        
    }
    
    //getting the weekly pay 
    public double getAnnualSalary(double p){
        double r, g, m;
        r = (annualSalary / 52);
        g = (bonus / 52);
        m = (r + g);
        //getting the rounded answer
        p = Math.round(m * 100) / 100;
        return p;
    }
    
    
    
}
