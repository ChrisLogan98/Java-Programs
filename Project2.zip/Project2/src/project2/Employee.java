//Chris Logan, Sam Perez
//CSC 161
//1/25/18
//Program 
package project2;

import java.util.ArrayList;

/**
 *
 * @author sam
 */

//This is the super class. All employees have all of these qualities
public class Employee {

    //declaring each variable 
    private String name;
    private String address;
    private int idNum;
    private int bossIdNum;
    
    //Constructor that reads in a String Array of our employees
    public Employee(String[] dataArray2){
        
        //declaring what positions each variable is located at
        name = dataArray2[1];
        address = dataArray2[2];
        //making these strings into integers
        idNum = Integer.parseInt(dataArray2[3]); 
        bossIdNum = Integer.parseInt(dataArray2[4]);       
    }
    
    //gets name
    public String getName(){
        return this.name;
    }
    
    //gets address
    public String getAddress(){
        return this.address;
    }
    
    //gets ID Number
    public int getIdNum(){
        return this.idNum;
    }
    
    //Gets the Bosses Id Number
    public int getBossIdNum(){
        return this.bossIdNum;
    }
}
