//Chris Logan, Sam Perez
//CSC 161
//1/25/18
//Program 2
package project2;

/**
 *
 * @author sam
 */

//Salaried Employee is another subclass of employee
public class SalariedEmployee extends Employee {
    
       //variables unquie to salaried employees
       double annualSalary;
     
    //Contructor taking in a string Array
    public SalariedEmployee(String[] dataArray2){
        
        //passing in the super variables
        super(dataArray2);
        annualSalary = Double.parseDouble(dataArray2[5]);
    }
    
    //Getting the weekly pay
    public double getAnnual(double e){
        double q;
        q = (annualSalary / 52);
        //rounding the answer
        e = Math.round(q * 100) / 100;
        return e;
    }
    
}
