//Chris Logan, Sam Perez
//CSC 161
//1/25/18
//Program Assignment 2

package project2;

import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 *
 * @author sam
 */
public class Project2 {
    
    public static void main(String[] args) throws FileNotFoundException{
        
        Scanner myScanner = new Scanner(System.in);
  
        Scanner file = new Scanner(new File("employeedata.txt")); //reads in txt file
        ArrayList<String[]> dataArray = new ArrayList<>(); //creates array
        ArrayList<Employee> employees = new ArrayList<>(); //creates array of employees
        ArrayList<HourlyEmployee> hourlyemploy = new ArrayList<>(); //creates array of hourly employees
        ArrayList<SalariedEmployee> salariedemploy = new ArrayList<>(); //creates array of salaried employees
        ArrayList<Supervisor> supervisor = new ArrayList<>(); //creates array of supervisors
        
        //checks for next line in file
        while (file.hasNextLine()){ 
            //puts the whole line in a String
            String stringHolder = (file.nextLine()); 
            
            //separates that string by ; and then puts them in a String Array
            String[] temp = stringHolder.split(";"); 
            
            //if the string arrays position 0 says "Hourly" then add it to the hourlyemploy array
            if(temp[0].equals("Hourly")){
               hourlyemploy.add(new HourlyEmployee(temp));
            }
            
            //if the string arrays position 0 says "Salaried" then add it to the salariedemploy array
            else if(temp[0].equals("Salaried")){
                salariedemploy.add(new SalariedEmployee(temp));
            }
            
            //if the string arrays position 0 says "Supervisor" then add it to the supervisor array
            else{
                supervisor.add(new Supervisor(temp));
            }
         
        }
        //you must close out the file
        file.close();
        
       
        /*
        for (int i=0; i < dataArray.size(); i++){
            
            for (int j=0; j < dataArray.get(i).length; j++){
                System.out.println(dataArray.get(i)[j]); 
            }
        
        }*/
        //System.out.println(dataArray);
       
       
       
       
        
        while(true){ //loops program again until user presses X
            
            System.out.println("\n" + "\t" + "Employee Lookup Program");
            System.out.println("\n" + "A) Find all employees with a given title");
            System.out.println("\n" + "B) Find a single employee");
            System.out.println("\n" + "X) Exit the program"); //prompts user to make a choice
            
            System.out.println("\n" + "Please enter either A,B, or X:");
            String choice = myScanner.nextLine();
            
            if (choice.equalsIgnoreCase("X")){ //kills program
                System.out.println("Good-bye!!");
                System.exit(0);
            }
            
            else if (choice.equalsIgnoreCase("A")){ //options for choice A
              System.out.println("\n" + "1) Hourly Employee");  
              System.out.println("\n" + "2) Salaried Employee");
              System.out.println("\n" + "3) Supervisory Employee");
              
              System.out.println("\n" + "Please enter either 1, 2, or 3:");
              String choice2 = myScanner.nextLine();
              
              if (choice2.equals("1")){ //shows hourly employees
                  System.out.println("\n" + "Name" + "\t\t" + "ID" + "\t\t" + "Gross Weekly Pay");
                  for (int i=0; i<hourlyemploy.size(); i++){
                      System.out.println(hourlyemploy.get(i).getName()+ "\t" + hourlyemploy.get(i).getIdNum() + "\t\t" + hourlyemploy.get(i).getGrossPay(i));
                  }
                 
              }
              
              else if (choice2.equals("2")){ //shows salaried employees
                  System.out.println("\n" + "Name" + "\t\t\t" + "ID" + "\t\t" + "Gross Weekly Pay");
                  for(int k = 0; k < salariedemploy.size(); k++){
                      System.out.println(salariedemploy.get(k).getName() + "\t\t" + salariedemploy.get(k).getIdNum() + "\t\t" + salariedemploy.get(k).getAnnual(k));
                  }
              }
              
              else if (choice2.equals("3")){ //shows supervisory employee
                  System.out.println("\n" + "Name" + "\t\t\t" + "ID" + "\t\t" + "Gross Weekly Pay" + "\t\t" + "Direct Reports");
                  for(int u = 0; u < supervisor.size(); u++){
                      System.out.println(supervisor.get(u).getName() + "\t\t" + supervisor.get(u).getIdNum() + "\t\t" + supervisor.get(u).getAnnualSalary(u) + "\t\t" + hourlyemploy.get(u).getBossIdNum() + "\t\t"+ salariedemploy.get(u).getBossIdNum());
                  }
              }
              
              else{ //repeats main menu
                  System.out.println("Invalid choice, please try again." + "\n");
                  continue;
              }
            }
            
            else if (choice.equalsIgnoreCase("B")){ //choice B
                System.out.println("Enter the ID of the employee");
                String choice3 = myScanner.nextLine(); //allows user to search for person using ID number
                int re= Integer.parseInt(choice3); //turns the ID into an integer
                boolean nameFound = false; //boolean set to false
                //goes through the hourlyemploy array to see if the ID num is in there
                for (int r=0; r< hourlyemploy.size(); r++){
                    //if the id number is in here then it will print out the name, id number, and hourly employee
                    if ((hourlyemploy.get(r).getIdNum() == re)){
                        System.out.print(hourlyemploy.get(r).getName()+ "\t\t" + hourlyemploy.get(r).getIdNum() + "\t\t" + "Hourly Employee" + "\n");
                        nameFound = true; //sets nameFound to true
                    }
                }
                
                //goes through the salariedemploy array to see if the ID num is in there
                for (int b=0; b < salariedemploy.size(); b++){
                    //if the id number is in here then it will print out the name, id number, and salaried employee
                    if ((salariedemploy.get(b).getIdNum() == re)){
                        System.out.print(salariedemploy.get(b).getName()+ "\t\t" + salariedemploy.get(b).getIdNum() + "\t\t" + "Salaried Employee" + "\n");
                        nameFound = true; //sets nameFound to true
                    }
                }
                
                //goes through the supervisor array to see if the Id num is in there
                for (int a=0; a < supervisor.size(); a++){
                    //if the id number is in here then it will print out the name, id number, and supervisor
                    if ((supervisor.get(a).getIdNum() == re)){
                        System.out.print(supervisor.get(a).getName()+ "\t\t" + supervisor.get(a).getIdNum() + "\t\t" + "Supervisor" + "\n");
                        nameFound = true; //sets nameFound to true
                    }
                               
                } 
                
                if(nameFound == false){
                    System.out.println("Employee ID does not match with our database. Try again");
                    //Prints out this message if nameFound returns false
                }
                else if(nameFound == true){
                    continue;
                    //contines if nameFound returns true
                }
            }
            //means you entered in an invalid choice on the main menu and will repeat until you enter something correct
            else{
                System.out.println("Invalid choice, please try again." + "\n");
                continue;
            }
        }
        
    }
    
    
    
}