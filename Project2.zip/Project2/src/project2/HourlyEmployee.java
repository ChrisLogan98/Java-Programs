//Chris Logan, Sam Perez
//CSC 161
//1/25/18
//Program 2
package project2;

import java.util.ArrayList;

/**
 *
 * @author sam
 */

//HourlyEmployee is a subclass to Employee 
public class HourlyEmployee extends Employee {
        
        //these are the variables that are unquie to Hourly Employees
        double payRate;
        double hours;
        double temp;
        double grossPay;
        
    //Contrustor that takes in a String Array
    public HourlyEmployee(String[] dataArray2){
        
        //passing in the super variables
        super(dataArray2);
        //Making these integers so that we can calcuate the gross weekly pay
        payRate = Double.parseDouble(dataArray2[5]);
        hours = Double.parseDouble(dataArray2[6]);
    }
    
    //getting their hourly pay
    public double getHourlyPay(double p){
        payRate = p;
        return payRate;
    }
    
    //Getting their hours
    public double getHours(double h){
        hours = h;
        return hours;
        
    }
    
    //Math to get the gross weekly pay
    public double getGrossPay(double g){
        //h holds the gross weekly pay
        double h = (payRate * hours);
        //we want to round the answer to two decimal places
        g = Math.round(h * 100) / 100;
        return g;
    }
    
    
    
}