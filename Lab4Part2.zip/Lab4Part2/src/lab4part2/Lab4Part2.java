//Chris Logan
//CSC 161
//1/23/18
//Part 2 of Lab 1, more fun with Interfaces
package lab4part2;

import java.util.Scanner;

/**
 *
 * @author cjlogan
 */
public class Lab4Part2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner myScanner = new Scanner(System.in);
       int number;
       int d = 1;
       double avg = 0.0;
       System.out.println("Type in 5 numbers and press <Space> after typing each number");
       System.out.println("They must be between 0 - 100"); //prompts user to type in 5 numbers
       while(d <= 5){
           System.out.println("Enter number " + d + " : ");
           number = myScanner.nextInt(); //accepts user input 5 times
           try{
            if(number < 100 && number > 0){
                d++; //count goes up by 1
                avg = avg + number; //does mathy stuff
            }
            else{
                throw new NumberSizeError(number); //throws the error message up
            }
           
          }
           catch(NumberSizeError e)//hold our custom error
           {
                System.out.println(e); //prints the error message
           }
       }
        avg = avg / (d - 1); //does the mathy stuff
        System.out.println("The average of the 5 numbers is " + avg); //prints out the avg
      
       
       
    }
    
}
