//Chris Logan
//CSC 161
//1/23/18
//Custom error creator
package lab4part2;

/**
 *
 * @author cjlogan
 */
public class NumberSizeError extends Exception{
    
    public NumberSizeError(int n)
    {
        super("Can't you read? It specifically says type in a number between 0 and 100. Then you think 'HAHA, I'll type in " + n + " ' \n That'll show"
                + " them. Try reading the instructions before you run the program"); //prints out this error statement
    }
}
