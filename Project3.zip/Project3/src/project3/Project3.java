//Tinh Cao, Chris Logan
//CSC 161
//2/25/18
//This program mimics a security login keypad and will return a greeting message if login credential is correct.

package project3;

import java.io.IOException;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author TCAO
 */
public class Project3 extends Application {

    public Button btn1, btn2, btn3, //creates buttons
            btn4, btn5, btn6,
            btn7, btn8, btn9,
            btn10, btn11, btn12, btnset, btnhd;
    public String file; 
    private final Label wordmonitor = new Label(); //creates label to display user input

    private final ArrayList<String> userinp = new ArrayList<>(); //creates an array of user inputs
    private final ArrayList<String> userinphd = new ArrayList<>(); //creates an array of user inputs that will be show

    @Override
    public void start(Stage primaryStage) throws IOException {

        Search searchtn = new Search();
        searchtn.readf();
        
        //all the buttons are initalized here
        btn1 = new Button("1");
        btn1.setOnAction(new sphandle(wordmonitor, btn1, primaryStage, searchtn));
        btn1.setPrefSize(150, 150);
        btn1.setStyle(" -fx-font: 40 arial; -fx-fill: Black; -fx-base: white");
        btn1.setId("1");
        
        btn2 = new Button("2");
        btn2.setTextAlignment(TextAlignment.CENTER);
        btn2.setOnAction(new sphandle(wordmonitor, btn2, primaryStage, searchtn));
        btn2.setPrefSize(150, 150);
        btn2.setId("2");
        btn2.setStyle(" -fx-font: 40 Arial; -fx-fill: Black; -fx-base: white;");
        
        btn3 = new Button("3");
        btn3.setOnAction(new sphandle(wordmonitor, btn3, primaryStage, searchtn));
        btn3.setPrefSize(150, 150);
        btn3.setId("3");
        btn3.setStyle(" -fx-font: 40 arial; -fx-fill: Black; -fx-base: white;");
        
        btn4 = new Button("4");
        btn4.setOnAction(new sphandle(wordmonitor, btn4, primaryStage, searchtn));
        btn4.setPrefSize(150, 150);
        btn4.setId("4");
        btn4.setStyle(" -fx-font: 40 arial; -fx-fill: Black; -fx-base: white;");
        
        btn5 = new Button("5");
        btn5.setOnAction(new sphandle(wordmonitor, btn5, primaryStage, searchtn));
        btn5.setPrefSize(150, 150);
        btn5.setId("5");
        btn5.setStyle(" -fx-font: 40 arial; -fx-fill: Black; -fx-base: white;");
        
        btn6 = new Button("6");
        btn6.setOnAction(new sphandle(wordmonitor, btn6, primaryStage, searchtn));
        btn6.setPrefSize(150, 150);
        btn6.setId("6");
        btn6.setStyle(" -fx-font: 40 arial; -fx-fill: Black; -fx-base: white;");
        
        btn7 = new Button("7");
        btn7.setOnAction(new sphandle(wordmonitor, btn7, primaryStage, searchtn));
        btn7.setPrefSize(150, 150);
        btn7.setId("7");
        btn7.setStyle(" -fx-font: 40 arial; -fx-fill: Black; -fx-base: white;");
        
        btn8 = new Button("8");
        btn8.setOnAction(new sphandle(wordmonitor, btn8, primaryStage, searchtn));
        btn8.setPrefSize(150, 150);
        btn8.setId("8");
        btn8.setStyle(" -fx-font: 40 arial; -fx-fill: Black; -fx-base: white;");
        
        btn9 = new Button("9");
        btn9.setStyle(" -fx-font: 40 arial; -fx-fill: Black; -fx-base: white;");
        btn9.setOnAction(new sphandle(wordmonitor, btn9, primaryStage, searchtn));
        btn9.setPrefSize(150, 150);
        btn9.setId("9");
        btn9.setStyle(" -fx-font: 40 arial; -fx-fill: Black; -fx-base: white;");
        
        btn10 = new Button("*");
        btn10.setOnAction(new sphandle(wordmonitor, btn10, primaryStage, searchtn));
        btn10.setPrefSize(150, 150);
        btn10.setId("*");
        btn10.setStyle(" -fx-font: 70 arial; -fx-fill: Black; -fx-base: white;");
        btn10.setTextAlignment(TextAlignment.CENTER);
        btn10.setAlignment(Pos.CENTER);
        btn10.setPadding(new Insets(40, 0, 0, 0));

        btn11 = new Button("0");
        btn11.setOnAction(new sphandle(wordmonitor, btn11, primaryStage, searchtn));
        btn11.setPrefSize(150, 150);
        btn11.setId("0");
        btn11.setStyle(" -fx-font: 40 arial; -fx-fill: Black; -fx-base: white;");
        
        btn12 = new Button("#");
        btn12.setPrefSize(150, 150);
        btn12.setId("#");
        btn12.setOnAction(new sphandle(wordmonitor, btn12, primaryStage, searchtn));
        btn12.setStyle(" -fx-font: 40 arial; -fx-fill: Black; -fx-base: white;");

        ArrayList<Button> allbut = new ArrayList<>(); //adds all the buttons from the keypad to the array
        allbut.add(btn1);
        allbut.add(btn2);
        allbut.add(btn3);
        allbut.add(btn4);
        allbut.add(btn5);
        allbut.add(btn6);
        allbut.add(btn7);
        allbut.add(btn8);
        allbut.add(btn9);
        allbut.add(btn10);
        allbut.add(btn11);
        allbut.add(btn12);

        BorderPane oripane = new BorderPane();// creates border pane to hold the buttons
        HBox[] hbox1 = new HBox[4]; //creates the border and windows
        VBox vbox = new VBox(10); 

        int buttonindex = 0;  //This index holds the position of button in the arraylist

        for (int i = 0; i < hbox1.length; i++) {
            int controlin = buttonindex + 3; //The maximum value of horizontal boxes for the array list
            hbox1[i] = new HBox(10);

            for (int j = buttonindex; j < controlin; j++) {
                hbox1[i].getChildren().add(allbut.get(buttonindex)); //sets up the buttons on the window
                buttonindex++;
            }
            HBox.setMargin(hbox1[i], new Insets(200, 200, 100, 100));
            hbox1[i].setAlignment(Pos.CENTER); //places and aligns the window according

        }
        vbox.getChildren().addAll(hbox1);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(20, 20, 20, 20));

        //Set center pane
        oripane.setPadding(new Insets(50, 10, 10, 10));
        oripane.setCenter(vbox);
        //New HBox to show the label to the user
        HBox usermonit2 = new HBox();
        //Put the HBox to gridpane, top region
        wordmonitor.setStyle(" -fx-font: 40 Javanese_Text; -fx-fill: Black; -fx-base: white;");
        usermonit2.getChildren().add(wordmonitor);
        usermonit2.setAlignment(Pos.TOP_CENTER);

        oripane.setTop(usermonit2);

        //Set pane
        primaryStage.setTitle("Apartment Entrance Security");

        btnset = new Button(); //creates "sign in" button for usage
        btnset.setText("Sign \n  in");
        btnset.setStyle(" -fx-font: 26 arial; -fx-fill: Black; -fx-base: white;");
        btnset.setPrefSize(100, 100);
        btnset.setId("s");
        btnset.setOnAction(new sphandle(wordmonitor, btnset, primaryStage, searchtn));
        
       

        VBox signe = new VBox(); //creates the container that "sign in" button sit in.
        signe.getChildren().add(btnset);
        BorderPane.setAlignment(signe, Pos.CENTER_LEFT); //sets the button off to the side
        BorderPane.setMargin(signe, new Insets(100, 0, 0, 0));
        oripane.setRight(signe);

        Scene scene = new Scene(oripane, 500, 600);
        primaryStage.setScene(scene); 
        primaryStage.show(); //shows everything

    }

    /**
     * @param args the command line arguments
     */
    //Create a a class to handle event
    public class sphandle implements EventHandler<ActionEvent> {

        private final Label sourcelb;
        private final Button buttonp; //these are final because the computer suggusted so. They don't affect the program anyway. 
        private final Stage stage;
        private final Search tenantlist;

        //The constructor will accept a lable and the button that is clicked
        public sphandle(Label eventlb, Button b, Stage s, Search tenant) {
            sourcelb = eventlb;
            buttonp = b;
            stage = s;
            tenantlist = tenant;
            
        }

        //The method handle will get the data from the clicked button 
        //and save the data in an array
        //It also modified the panel that is displayed to the user
        @Override
        public void handle(ActionEvent e) {
            userinp.add(buttonp.getId());
            userinphd.add("*");
            String test1;

            if (buttonp.getId().equals("*")) { //when the asterisk is clicked, it clears the line
                userinp.clear(); //clears string ArrayList of user input
                userinphd.clear(); 
                test1 = String.join("", userinphd); //turns ArrayList into a string
                wordmonitor.setText(test1); //set string to label and display it
            } else if (buttonp.getId().equals("s")) {

                test1 = String.join("", userinp); //creats string from user input and stores it
                
                if (!tenantlist.search(test1).equals("")) { //if the input matchs with the data, 
                    Stage dialog = new Stage(); 
                    dialog.initModality(Modality.WINDOW_MODAL); 

                    dialog.initOwner(stage); //sets parent stage to the pop-up window
                    VBox dialogVbox = new VBox(20); 
                    Text welcom = new Text(); //this node is displayed below
                    String home = "Access Granted. Welcome home, "; //displays when the pin number or combination match
                    welcom.setText(home.concat(tenantlist.search(test1))); // puts the home string to Text node. 
                    welcom.setStyle(" -fx-font: 20 Javanese_Text; -fx-fill: Black; -fx-base: white;"); //sets font/ style
                    dialogVbox.getChildren().add(welcom);
                    dialogVbox.setAlignment(Pos.CENTER);
                    Scene dialogScene = new Scene(dialogVbox, 450, 200);
                    dialog.setScene(dialogScene); //pop up the new window
                    dialog.show();
                    userinp.clear(); //clear user input
                    userinphd.clear(); //clear user input
                    test1 = String.join("", userinphd);
                    wordmonitor.setText(test1);
                } else {
                    userinp.clear();
                    userinphd.clear();
                    test1 = String.join("", userinphd);
                    Stage dialog = new Stage();
                    dialog.initModality(Modality.WINDOW_MODAL);

                    dialog.initOwner(stage);  //basically the same thing as above except it checks if there is no match
                    VBox dialogVbox = new VBox(20);
                    Text wrong=new Text("Access Denied. PIN or combination is incorrect"); //activates when pin number or combination doesn't match with the numbers in the file
                    wrong.setStyle(" -fx-font: 20 Javanese_Text; -fx-fill: Black; -fx-base: white;"); //sets style
                    dialogVbox.getChildren().add(wrong); 
                    dialogVbox.setAlignment(Pos.CENTER);
                    Scene dialogScene = new Scene(dialogVbox, 600, 200);
                    dialog.setScene(dialogScene);
                    dialog.show();
                    wordmonitor.setText(test1); 
                }

            } else {
                test1 = String.join("", userinphd); //default case
                //This is for search
                wordmonitor.setText(test1);
            }
        }

    }

    public static void main(String[] args) {
        launch(args); //launches program
    }

}
