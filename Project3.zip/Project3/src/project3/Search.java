//Tinh Cao, Chris Logan
//CSC 161
//2/25/18
// This class will read in the file and return the name of tenant
package project3;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;


public class Search {

    private String path = "tenants.txt";
    private final ArrayList<Tenant> tenant = new ArrayList<>();

    public void readf() throws IOException {
        Scanner rf = new Scanner(new File(path));

        while (rf.hasNext()) {
            //finds the next line and builds a string
            String input = rf.nextLine();
            //scanner to read the string and split it at the ;'s
            Scanner s = new Scanner(input).useDelimiter("\\s");
            //assigns the first field for sorting, second to name, and final to bid
            tenant.add(new Tenant(s.next(), s.next(), s.next()));

        }

    }

    public String search(String lookingFor) {
        String[] raw = lookingFor.split("#");
        for (Tenant s : tenant) {
            if (raw[0].trim().equals(s.getFloor())) {
                if (raw[1].trim().equals(s.getPin())) {
                    return s.getName();
                }
            }
        }

        return "";
    }
}

