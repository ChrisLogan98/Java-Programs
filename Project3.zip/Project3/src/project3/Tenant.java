//Tinh Cao, Chris Logan
//CSC 161
//2/25/18
//This class will return Tenant data

package project3;


public class Tenant {

    private final String floor;
    private final String pin;
    private final String name;

    public Tenant(String fl, String pn, String ne) {
        floor = fl;
        pin = pn;
        name = ne;
    }

    public String getFloor() {
        return this.floor;
    }

    public String getPin() {
        return this.pin;
    }

    public String getName() {
        return this.name;
    }

}
