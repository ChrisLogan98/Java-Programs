//Chris Logan
//CSC 161
//3/6/18
//This class is solely for making the stupid error go away
package lab10;

/** 
   These two classes represent exceptions
   thrown by the queue methods.
*/

class QueueOverFlowException extends RuntimeException
{    
}

class EmptyQueueException extends RuntimeException
{    
}