/*
 * Jennifer Dust (mostly)
 * Fixed by Chris Logan and Bjorn Shroda. 
 * 1/26/18
 * Lab 5
 * This is a JavaFX lab, look at the code below and fix its implementation. 
 * We attempt to play tic-tac-toe!
 */
package lab5;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Lab5 extends Application {
  
    // variable to hold the next player
    public char player;

    // Top row buttons (really, just indicators)
    public Button buttonX, buttonO;

    // Buttons for the squares in the tic-tac-toe
    // board

    public Button button1, button2, button3,
                  button4, button5, button6,
                  button7, button8, button9;

    public static void main(String[] args) 
    {	
            // method launch is declared in the 
            // Application class.  It calls 
            // method start, below
            launch(args);
    }  // end main

    // Start is called by launch.  Start creates
    // the container for the page (here, it's a
    // vertical box (VBox) named 'root'), puts
    // content into the container, puts the
    // container into a scene, puts the scene
    // into a stage, then makes the page visible.
    public void start(Stage stage)
    {
        // Set up the screen layout.  The first
        // row, at the top, will have the text
        // label "Player", then an indicator button 
        // for X and an indicator button for 0.
        // 
        // The next three rows will have a grid for
        // the TicTacToe board. The buttons will be arranged 
        // in this order
        // 1  2  3
        // 4  5  6
        // 7  8  9

        // overall container for the page, with padding
        // of 8 pixels around the 2 elements.
        VBox root = new VBox(8);  

        root.setPrefWidth(500);  // 500 pixels wide for now

        // set up the top row of the container

        player = 'X';

        Label player = new Label("Player: ");
        player.setStyle("-fx-font: 32 Arial;");

        buttonX = new Button("X");
        buttonX.setPrefSize(140,140);
        buttonX.setStyle(" -fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");

        buttonO = new Button("O");
        buttonO.setPrefSize(140,140);
        buttonO.setStyle(" -fx-font: 40 arial; -fx-fill: Black; -fx-base: Black;");

        // Put the top row entries in a TilePane
        TilePane tilePane = new TilePane();
        tilePane.setStyle(" -fx-padding: 3 30 3 30;");
        tilePane.setHgap(10);  // horizontal space between entries
        tilePane.getChildren().add(player);
        tilePane.getChildren().add(buttonX);
        tilePane.getChildren().add(buttonO);

        // Add the tilePane object to the root container
        root.getChildren().add(tilePane);


        // Set up the 9 buttons for the board.  Each
        // button is distinguished by its ID.  The ID 
        // can be examined by the code in the handle
        // method of the SimpleEventHandler object.

        // buttons for the first row of the game
        button1 = new Button(" ");
        button1.setPrefSize(150,150);
        button1.setId("1");
        button1.setOnAction(new SimpleEventHandler());

        button2 = new Button(" ");
        button2.setPrefSize(150,150);
        button2.setId("2");
        button2.setOnAction(new SimpleEventHandler());

        button3 = new Button(" ");
        button3.setPrefSize(150,150);
        button3.setId("3");
        button3.setOnAction(new SimpleEventHandler());

        // buttons for the second row of the game
        button4 = new Button(" ");
        button4.setPrefSize(150,150);
        button4.setId("4");
        button4.setOnAction(new SimpleEventHandler());

        button5 = new Button(" ");
        button5.setPrefSize(150,150);
        button5.setId("5");
        button5.setOnAction(new SimpleEventHandler());

        button6 = new Button(" ");
        button6.setPrefSize(150,150);
        button6.setId("6");
        button6.setOnAction(new SimpleEventHandler());

        // buttons for the third row of the game
        button7 = new Button(" ");
        button7.setPrefSize(150,150);
        button7.setId("7");
        button7.setOnAction(new SimpleEventHandler());

        button8 = new Button(" ");
        button8.setPrefSize(150,150);
        button8.setId("8");
        button8.setOnAction(new SimpleEventHandler());

        button9 = new Button(" ");
        button9.setPrefSize(150,150);
        button9.setId("9");
        button9.setOnAction(new SimpleEventHandler());

        // set up the displayable image

        GridPane gridPane = new GridPane();
        gridPane.setPrefSize(500, 500); // default size
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        String style = "";  // style for the overall grid
        style += " -fx-background-insets: 0,1,2; -fx-background-radius: 3,2,1; ";
        style += " -fx-padding: 3 30 3 30; -fx-text-fill: black; -fx-font: 62 arial;";

        gridPane.setStyle(style);

        // Add the buttons to the grid.
        // Layout is column first, then row
        gridPane.add(button1, 0, 0);
        gridPane.add(button2, 1, 0);
        gridPane.add(button3, 2, 0);
        gridPane.add(button4, 0, 1);
        gridPane.add(button5, 1, 1);
        gridPane.add(button6, 2, 1);
        gridPane.add(button7, 0, 2);
        gridPane.add(button8, 1, 2);
        gridPane.add(button9, 2, 2);

        // Add the grid to the root container
        root.getChildren().add(gridPane);

        // Create a scene, add it to the stage,
        // title it, then make it visible

        stage.setScene(new Scene(root));
        stage.setTitle("Tic-Tac-Toe");
        stage.show();

    }  // end method start

    // Handler class
    class SimpleEventHandler implements EventHandler<ActionEvent>
    {
        public void handle(ActionEvent event)
        {

            boolean winX = false;
            boolean winO = false;
            boolean noWin = true;
             
            


                // Identify the button that was clicked by examining its ID.
                // First, get the object that caused the event. 
                Object source = event.getSource();

                // Only buttons have event handlers, so cast the Object 
                // to a Button.
            Button clickedBtn = (Button) source; 

            // Retrieve the ID (as a String) of the Button who triggered
            // the event
            String sid = clickedBtn.getId();
            if(clickedBtn.getText().equalsIgnoreCase(" ")){
            if (player == 'X')
            {
                // Put an "X" on the button
                clickedBtn.setText("X");
                //noWin = false;
                // Toggle so that the next player will be "O"
                player = 'O';

                // flip the highlighting of the indicators at
                // the top of the window
                buttonX.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                buttonO.setStyle("-fx-font: 40 arial; -fx-fill: Black; -fx-base: Black;");
            }
            else
            {
                clickedBtn.setText("O");
                //noWin = false;
                player = 'X';

                buttonO.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                buttonX.setStyle("-fx-font: 40 arial; -fx-fill: Black; -fx-base: Black;");
            }
            }
            
            // Uncomment the line below if you want to see the button ID 
            // printed to the console window.  This might be useful for debugging.
             //System.out.println(sid); // prints the id of the button
                if(button1.getText().equals(button2.getText()) && button1.getText().equals(button3.getText())){
                    if(button1.getText().equals("X")){
                        
                        button1.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button2.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button3.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winX = true;
                        noWin = false;
                    }
                    else if(button1.getText().equals("O")){
                        
                        button1.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button2.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button3.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winO = true;
                        noWin = false;
                    }
                }
                else if(button1.getText().equals(button4.getText()) && button1.getText().equals(button7.getText())){
                    if(button1.getText().equals("X")){
                        
                        button1.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button4.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button7.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winX = true;
                        noWin = false;
                    }
                    else if(button1.getText().equals("O")){
                        
                        button1.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button4.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button7.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winO = true;
                        noWin = false;
                    }
                }
                else if(button1.getText().equals(button5.getText()) && button1.getText().equals(button9.getText())){
                    if(button1.getText().equals("X")){
                        
                        button1.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button5.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button9.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winX = true;
                        noWin = false;
                    }
                    else if(button1.getText().equals("O")){
                        
                        button1.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button5.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button9.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winO = true;
                        noWin = false;
                    }
                }
                else if(button2.getText().equals(button5.getText()) && button2.getText().equals(button8.getText())){
                    if(button2.getText().equals("X")){
                        
                        button2.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button5.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button8.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winX = true;
                        noWin = false;
                    }
                    else if(button2.getText().equals("O")){
                        
                        button2.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button5.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button8.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winO = true;
                        noWin = false;
                    }
                }
                else if(button3.getText().equals(button6.getText()) && button3.getText().equals(button9.getText())){
                    if(button3.getText().equals("X")){
                        
                        button3.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button6.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button9.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winX = true;
                        noWin = false;
                    }
                    else if(button3.getText().equals("O")){
                        
                        button3.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button6.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button9.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winO = true;
                        noWin = false;
                    }
                }
                else if(button4.getText().equals(button5.getText()) && button4.getText().equals(button6.getText())){
                    if(button4.getText().equals("X")){
                        
                        button4.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button5.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button6.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winX = true;
                        noWin = false;
                    }
                    else if(button4.getText().equals("O")){
                        
                        button4.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button5.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button6.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winO = true;
                        noWin = false;
                    }
                }
                else if(button7.getText().equals(button8.getText()) && button7.getText().equals(button9.getText())){
                    if(button7.getText().equals("X")){
                        
                        button7.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button8.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button9.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winX = true;
                        noWin = false;
                    }
                    else if(button7.getText().equals("O")){
                        
                        button7.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button8.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button9.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winO = true;
                        noWin = false;
                    }
                }
                else if(button3.getText().equals(button5.getText()) && button3.getText().equals(button7.getText())){
                    if(button3.getText().equals("X")){
                        
                        button3.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button5.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button7.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winX = true;
                        noWin = false;
                    }
                    else if(button3.getText().equals("O")){
                        
                        button3.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button5.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        button7.setStyle("-fx-font: 40 arial; -fx-fill: Green; -fx-base: Green;");
                        winO = true;
                        noWin = false;
                    }
                
                }
                if(button1.getText().equals(" ") || button2.getText().equals(" ") || button3.getText().equals(" ") || button4.getText().equals(" ") || button5.getText().equals(" ") || button6.getText().equals(" ") || button7.getText().equals(" ") || button8.getText().equals(" ") || button9.getText().equals(" ")){
                    noWin = false;
                }
                else{
                    noWin = true;
                }
                
                if(winX == true){
                    System.out.println("X WINS");
                }
                else if(winO == true){
                    System.out.println("O WINS");
                }
                else if(noWin == true){
                    button1.setStyle("-fx-font: 40 arial; -fx-fill: Red; -fx-base: Red;");
                    button2.setStyle("-fx-font: 40 arial; -fx-fill: Red; -fx-base: Red;");
                    button3.setStyle("-fx-font: 40 arial; -fx-fill: Red; -fx-base: Red;");
                    button4.setStyle("-fx-font: 40 arial; -fx-fill: Red; -fx-base: Red;");
                    button7.setStyle("-fx-font: 40 arial; -fx-fill: Red; -fx-base: Red;");
                    button8.setStyle("-fx-font: 40 arial; -fx-fill: Red; -fx-base: Red;");
                    button9.setStyle("-fx-font: 40 arial; -fx-fill: Red; -fx-base: Red;");
                }
                
            }  // end method handle
        }  // end class SimpleEventHandler

}  // end class GraphicDemo


